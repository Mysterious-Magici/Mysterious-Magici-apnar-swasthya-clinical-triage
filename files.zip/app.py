"""
Apnar Swasthya - Clinical Triage & Offline AI Copilot
------------------------------------------------------------------
Runs completely offline:
  * XGBoost triage model      -> xgboost_triage.pkl
  * Our own chatbot           -> chatbot_model.pkl + knowledge_base.py
  * No Gemini / OpenAI / API key anywhere
------------------------------------------------------------------
"""

import os
from datetime import datetime

import pandas as pd
import altair as alt
import streamlit as st

# ----------------- PAGE ICON (the green Apnar Swasthya logo) -----------------
# Streamlit needs the icon BEFORE set_page_config, so we load it first.
PAGE_ICON = "🩺"                      # fallback if the logo file is missing
for _candidate in ("logo.png", "logo.jpeg", "logo.jpg"):
    if os.path.exists(_candidate):
        try:
            from PIL import Image
            PAGE_ICON = Image.open(_candidate)
            break
        except Exception:
            PAGE_ICON = "🩺"

# ----------------- PAGE CONFIG -----------------
st.set_page_config(
    page_title="Apnar Swasthya | Clinical Triage & AI Copilot",
    page_icon=PAGE_ICON,
    layout="wide",
    initial_sidebar_state="expanded",
)

# ----------------- LOCAL MODULES -----------------
from chatbot_engine import load_chatbot, generate_reply   # noqa: E402
from pdf_report import build_pdf                          # noqa: E402

try:
    import joblib
    HAS_JOBLIB = True
except ImportError:
    HAS_JOBLIB = False

# ----------------- STYLING -----------------
st.markdown("""
<style>
    .badge-critical {background:#fee2e2;color:#991b1b;font-weight:600;
        padding:4px 10px;border-radius:4px;font-size:.85rem;}
    .badge-moderate {background:#fef3c7;color:#92400e;font-weight:600;
        padding:4px 10px;border-radius:4px;font-size:.85rem;}
    .badge-stable   {background:#dcfce7;color:#166534;font-weight:600;
        padding:4px 10px;border-radius:4px;font-size:.85rem;}
    div[data-testid="stMetricValue"] {font-size:1.4rem;}
</style>
""", unsafe_allow_html=True)


# ==================================================================
# RESOURCE LOADERS
# ==================================================================
@st.cache_resource
def load_ml_assets():
    """Load the trained XGBoost triage model and its encoders."""
    paths = ("xgboost_triage.pkl", "feature_encoders.pkl", "target_encoder.pkl")
    if HAS_JOBLIB and all(os.path.exists(p) for p in paths):
        try:
            return joblib.load(paths[0]), joblib.load(paths[1]), joblib.load(paths[2]), True
        except Exception as err:
            st.sidebar.error(f"Could not load triage model: {err}")
    return None, None, None, False


@st.cache_resource
def load_bot():
    """Load our own trained chatbot (chatbot_model.pkl)."""
    return load_chatbot()


xgb_model, feature_encoders, target_encoder, is_model_ready = load_ml_assets()
chat_bundle = load_bot()


# ==================================================================
# FORM DEFAULTS  (used by the Reset Parameters button)
# ==================================================================
DEFAULTS = {
    "age": 45, "gender": "Male", "ses": "Low",
    "insurance": "Covered", "hospital": "Government",
    "temp": 102.5, "spo2": 95.0, "resp": 22.0, "hr": 108.0, "bmi": 24.5,
    "hb": 13.5, "calcium": 8.8, "phos": 3.2, "plt": 35.0, "chol": 165.0,
    "sodium": 137.0, "potassium": 4.0, "neutro": 78.0, "lympho": 18.0,
    "crp": 18.5, "wbc": 3.2,
}

for _key, _val in DEFAULTS.items():
    st.session_state.setdefault(_key, _val)


def reset_parameters():
    """Put every input widget back to its default value."""
    for key, value in DEFAULTS.items():
        st.session_state[key] = value
    st.session_state.pop("triage_data", None)


def reset_chat():
    """Empty the conversation."""
    st.session_state.messages = []


def reset_everything():
    reset_parameters()
    reset_chat()


# ==================================================================
# SIDEBAR
# ==================================================================
with st.sidebar:
    st.header("⚙️ System Status")

    if is_model_ready:
        st.success("Triage engine: XGBoost active")
    else:
        st.warning("Triage engine: simulation mode\n\nPlace the three .pkl files "
                   "next to app.py to activate the trained model.")

    if chat_bundle is not None:
        st.success("Copilot: Apnar Swasthya offline bot")
    else:
        st.warning("Copilot: knowledge base only\n\nRun `python train_chatbot.py` "
                   "to build chatbot_model.pkl.")

    st.caption("No API key required. Nothing leaves this machine.")

    st.divider()
    st.subheader("🧹 Reset Controls")
    st.button("Clear Patient Parameters", use_container_width=True,
              on_click=reset_parameters)
    st.button("Clear Chat Conversation", use_container_width=True,
              on_click=reset_chat)
    st.button("Clear Everything (New Patient)", type="primary",
              use_container_width=True, on_click=reset_everything)

    st.divider()
    st.caption("Apnar Swasthya is a decision-support prototype. "
               "It does not diagnose and does not replace a doctor.")


# ==================================================================
# HEADER
# ==================================================================
col_logo, col_title = st.columns([1, 6], vertical_alignment="center")
with col_logo:
    if os.path.exists("logo.png"):
        st.image("logo.png", width=110)
    elif os.path.exists("logo.jpeg"):
        st.image("logo.jpeg", width=110)
    else:
        st.markdown("## 🩺")
with col_title:
    st.title("Apnar Swasthya Clinical Assistant")
    st.caption("Automated Disease Triage System & Interactive Differential Diagnostic Support")

st.divider()

left_col, right_col = st.columns([5, 6], gap="large")

# ==================================================================
# LEFT COLUMN - PATIENT INPUT
# ==================================================================
with left_col:
    st.subheader("📋 Patient Clinical Workup")

    with st.expander("1. Demographics & Administration", expanded=True):
        c1, c2 = st.columns(2)
        with c1:
            age = st.slider("Age (Years)", 1, 110, key="age")
            gender = st.selectbox("Gender", ["Male", "Female"], key="gender")
            ses = st.selectbox("Socio-economic Status", ["Low", "Middle", "High"], key="ses")
        with c2:
            insurance = st.selectbox("Insurance", ["Covered", "Not-Covered"], key="insurance")
            hospital = st.selectbox("Hospital Type", ["Government", "Private", "Public"],
                                    key="hospital")

    with st.expander("2. Vital Signs", expanded=True):
        c1, c2 = st.columns(2)
        with c1:
            temp = st.number_input("Temperature (°F)", step=0.1, key="temp",
                                   help="Normal: 97.8 – 99.1 °F")
            spo2 = st.number_input("SpO2 (%)", min_value=50.0, max_value=100.0,
                                   step=0.5, key="spo2", help="Normal: 95 – 100 %")
            resp = st.number_input("Resp. Rate (bpm)", min_value=5.0, max_value=60.0,
                                   step=1.0, key="resp", help="Normal: 12 – 20")
        with c2:
            hr = st.number_input("Heart Rate (bpm)", min_value=30.0, max_value=220.0,
                                 step=1.0, key="hr", help="Normal: 60 – 100")
            bmi = st.number_input("BMI (kg/m²)", min_value=10.0, max_value=60.0,
                                  step=0.1, key="bmi", help="Normal: 18.5 – 24.9")

    with st.expander("3. Laboratory Markers", expanded=False):
        c1, c2 = st.columns(2)
        with c1:
            hb = st.number_input("Haemoglobin (g/dL)", step=0.1, key="hb",
                                 help="Normal: 12.0 – 17.5")
            calcium = st.number_input("Calcium (mg/dL)", step=0.1, key="calcium",
                                      help="Normal: 8.5 – 10.2")
            phos = st.number_input("Phosphorus (mg/dL)", step=0.1, key="phos",
                                   help="Normal: 2.5 – 4.5")
            plt_count = st.number_input("Platelets (×10⁹/L)", step=5.0, key="plt",
                                        help="Normal: 150 – 450")
            chol = st.number_input("Cholesterol (mg/dL)", step=1.0, key="chol",
                                   help="Normal: < 200")
            sodium = st.number_input("Sodium (mEq/L)", step=1.0, key="sodium",
                                     help="Normal: 135 – 145")
        with c2:
            potassium = st.number_input("Potassium (mIU/L)", step=0.1, key="potassium",
                                        help="Normal: 3.5 – 5.0")
            neutro = st.number_input("Neutrophils (%)", step=1.0, key="neutro",
                                     help="Normal: 40 – 70 %")
            lympho = st.number_input("Lymphocytes (%)", step=1.0, key="lympho",
                                     help="Normal: 20 – 40 %")
            crp = st.number_input("CRP (mg/dL)", step=0.5, key="crp",
                                  help="Normal: < 1.0")
            wbc = st.number_input("WBC Count (×10⁹/L)", step=0.1, key="wbc",
                                  help="Normal: 4.5 – 11.0")

    predict_btn = st.button("Run Clinical Triage Assessment", type="primary",
                            use_container_width=True)

# Feature names must match the training script exactly
patient_profile = {
    "Age": age, "Gender": gender, "Socio-economic Status": ses,
    "Insurance": insurance, "Hospital Type": hospital,
    "Body Temperature": temp, "SpO2": spo2, "Respiratory Rate": resp,
    "Heart Rate": hr, "BMI": bmi, "Haemoglobin": hb,
    "Calcium": calcium, "Phosphorus": phos, "Platelet Count": plt_count,
    "Cholesterol": chol, "Sodium": sodium, "Potassium": potassium,
    "Neutrophils": neutro, "Lymphocytes": lympho, "CRP": crp,
    "WBC Count": wbc,
}


# ==================================================================
# TRIAGE ENGINE
# ==================================================================
def perform_inference(data: dict) -> dict:
    if is_model_ready:
        df = pd.DataFrame([data])
        for col in ["Gender", "Socio-economic Status", "Insurance", "Hospital Type"]:
            if col in feature_encoders:
                df[col] = feature_encoders[col].transform(df[col])
        probs = xgb_model.predict_proba(df)[0]
        classes = target_encoder.classes_
        results = {classes[i]: float(probs[i]) for i in range(len(classes))}
        return dict(sorted(results.items(), key=lambda kv: kv[1], reverse=True)[:5])

    # Fallback heuristic if the .pkl files are missing
    if data["Platelet Count"] < 100.0 and data["Body Temperature"] >= 101.0:
        return {"Dengue": 0.89, "Malaria": 0.07, "Typhoid": 0.03, "Common Cold": 0.01}
    if data["SpO2"] < 92.0:
        return {"Asthma/COPD": 0.81, "Cardiovascular Disease": 0.12, "Tuberculosis": 0.05}
    return {"Common Cold": 0.65, "Hypertension": 0.18, "Type-2 Diabetes": 0.12}


if "triage_data" not in st.session_state or predict_btn:
    st.session_state.triage_data = perform_inference(patient_profile)
    st.session_state.current_profile = patient_profile
    if predict_btn:
        st.session_state.messages = []      # fresh conversation for a new assessment

triage_data = st.session_state.triage_data
top_disease = list(triage_data.keys())[0]
top_confidence = list(triage_data.values())[0] * 100


# ==================================================================
# RIGHT COLUMN - RESULTS + CHAT
# ==================================================================
with right_col:
    st.subheader("📊 Triage Stratification")

    is_critical = (
        patient_profile["Platelet Count"] < 50.0
        or patient_profile["SpO2"] < 92.0
        or patient_profile["Body Temperature"] >= 104.0
        or (top_confidence > 80.0 and top_disease in ["Dengue", "Cardiovascular Disease"])
    )
    status_text = "CRITICAL / IMMEDIATE REVIEW" if is_critical else "PRIORITY TRIAGE"
    badge_class = "badge-critical" if is_critical else "badge-moderate"
    alert_badge = f'<span class="{badge_class}">{status_text}</span>'

    c1, c2 = st.columns(2)
    with c1:
        st.markdown("**Primary Differential:**")
        st.markdown(f"### {top_disease}")
    with c2:
        st.markdown("**Status & Confidence:**")
        st.markdown(f"{alert_badge} &nbsp; **{top_confidence:.1f}%**", unsafe_allow_html=True)

    chart_df = pd.DataFrame({
        "Condition": list(triage_data.keys()),
        "Probability (%)": [v * 100 for v in triage_data.values()],
    }).sort_values("Probability (%)")

    chart = (
        alt.Chart(chart_df)
        .mark_bar(cornerRadiusTopRight=5, cornerRadiusBottomRight=5, color="#0f766e")
        .encode(
            x=alt.X("Probability (%)", title="Model Confidence (%)",
                    scale=alt.Scale(domain=[0, 100])),
            y=alt.Y("Condition", sort="-x", title=""),
            tooltip=["Condition", alt.Tooltip("Probability (%)", format=".1f")],
        )
        .properties(height=220)
    )
    st.altair_chart(chart, use_container_width=True)

    st.divider()

    # ---------------- CHATBOT ----------------
    st.subheader("🤖 Clinical Decision Copilot")
    st.caption("Runs on our own trained model - no API key, no internet.")

    if "messages" not in st.session_state:
        st.session_state.messages = []

    if not st.session_state.messages:
        st.session_state.messages = [{
            "role": "assistant",
            "content": (
                f"Hello Doctor. I have reviewed the entered vitals and laboratory profile. "
                f"The primary differential is **{top_disease} ({top_confidence:.1f}% confidence)**. "
                "Ask me why, what the red flags are, which tests to order, or how it is managed."
            ),
        }]

    st.caption("Quick Inquiries:")
    q1, q2, q3 = st.columns(3)
    quick_query = None
    if q1.button("Why this diagnosis?", use_container_width=True):
        quick_query = "Why this diagnosis? Which vitals and lab anomalies led to it?"
    if q2.button("Red Flags & Risks", use_container_width=True):
        quick_query = "What red flags and emergent risks should be monitored right now?"
    if q3.button("Recommended Tests", use_container_width=True):
        quick_query = "Which confirmatory laboratory or imaging tests should I order?"

    for msg in st.session_state.messages:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])

    chat_prompt = st.chat_input("Ask about differentials, red flags, tests, management…")
    active_prompt = chat_prompt or quick_query

    if active_prompt:
        st.session_state.messages.append({"role": "user", "content": active_prompt})
        with st.chat_message("user"):
            st.markdown(active_prompt)

        with st.chat_message("assistant"):
            with st.spinner("Analysing clinical data…"):
                reply = generate_reply(
                    question=active_prompt,
                    profile=patient_profile,
                    triage=triage_data,
                    bundle=chat_bundle,
                )
            st.markdown(reply)
        st.session_state.messages.append({"role": "assistant", "content": reply})

    st.divider()

    # ---------------- PDF EXPORT ----------------
    st.subheader("📄 Export Report")
    col_pdf, col_clear = st.columns([3, 2])

    with col_pdf:
        try:
            pdf_bytes = build_pdf(
                profile=patient_profile,
                triage=triage_data,
                messages=st.session_state.messages,
                top_disease=top_disease,
                confidence=top_confidence,
                status=status_text,
                model_mode="XGBoost" if is_model_ready else "Simulation",
            )
            st.download_button(
                "⬇️ Download / Print Report (PDF)",
                data=pdf_bytes,
                file_name=f"apnar_swasthya_triage_{datetime.now():%Y%m%d_%H%M}.pdf",
                mime="application/pdf",
                use_container_width=True,
            )
        except Exception as err:
            st.error(f"PDF generation failed: {err}. Run: pip install fpdf2")

    with col_clear:
        st.button("Clear Chat", use_container_width=True, on_click=reset_chat,
                  key="clear_chat_main")

    st.caption("The PDF contains the patient parameters, the probability table and the "
               "full conversation. Open it and press Ctrl+P to print.")
